import Cart from "../pageObject/cartPage.js";

describe('Verify Item in Cart Page', () => {

    it('Verify Item and Amount is visible', () => {

        cy.visit('https://www.amazon.com/')

        
            const cart = new Cart();
            cart.setSearchParam("TP-Link N450 WiFi Router - Wireless Internet Router for Home (TL-WR940N)")
            cart.addItemToCart()
            cart.verifyItemInCart()

         })

})