class Cart
{
    setSearchParam(searchparam)
    {
        cy.get('#twotabsearchtextbox')
        .should('be.visible' )
        .type(searchparam)
        .type("{enter}")
    }

    addItemToCart()
    {
    
        cy.get('#search > div.s-desktop-width-max.s-desktop-content.s-opposite-dir.s-wide-grid-style.sg-row > div.sg-col-20-of-24.s-matching-dir.sg-col-16-of-20.sg-col.sg-col-8-of-12.sg-col-12-of-16 > div > span.rush-component.s-latency-cf-section > div.s-main-slot.s-result-list.s-search-results.sg-row > div:nth-child(7) > div > div > span > div > div > div > div.puisg-col.puisg-col-4-of-12.puisg-col-8-of-16.puisg-col-12-of-20.puisg-col-12-of-24.puis-list-col-right > div > div > div.a-section.a-spacing-none.puis-padding-right-small.s-title-instructions-style > h2 > a > span')
        .type("{enter}")
        .get('#buybox-see-all-buying-choices > span > a')
        .click()
        .get('#a-autoid-2-offer-1 > span > input')
        .click()
        .get('#aod-offer-view-cart-1 > span > input')
        .click() 
    }

    verifyItemInCart()
    {
        cy.get('.a-truncate-full').should('have.text', 'TP-Link N450 WiFi Router - Wireless Internet Router for Home (TL-WR940N)')
        cy.get('.a-section > .a-size-medium').should('include.text', '$63.99')
    }
}

export default Cart;